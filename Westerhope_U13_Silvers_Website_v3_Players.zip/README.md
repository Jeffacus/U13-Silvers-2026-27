# Westerhope United U13 Silvers 2026/27

Mobile-first season hub for parents and supporters.

## Current roster

1 Johnny Collinson  
2 Blake Smith  
4 Kane Rogerson  
5 Ewan Dodds  
6 Theo Demosthenous  
7 Freddie Cowan  
8 Oliver Stubbs  
10 Jake Armstrong  
11 Ollie Anderson  
12 Joseph Winwood  
14 Charlie Mulligan  
15 Kyran Archbold  
19 Yusuf Syed Ubaidur Rahman

Archie Mawson is retained only in historical 2025/26 records and is not part of the current squad.
